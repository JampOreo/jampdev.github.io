const cds = document.querySelectorAll('.cd');
const drive = document.getElementById('dvd-drive');

// Audio elements
const sfxGrab = document.getElementById('sfx-grab');
const sfxDrop = document.getElementById('sfx-drop');
const sfxInsert = document.getElementById('sfx-insert');

// Scatter CDs randomly on the bottom half of the table on load
cds.forEach((cd, index) => {
  const randomX = Math.random() * (window.innerWidth - 200) + 10;
  // Keep them in the bottom 60% of the screen
  const randomY = Math.random() * (window.innerHeight * 0.4) + (window.innerHeight * 0.5);
  const randomRotate = Math.random() * 360;

  cd.style.left = `${randomX}px`;
  cd.style.top = `${randomY}px`;
  cd.style.transform = `rotate(${randomRotate}deg)`;
  
  // Save base rotation for later
  cd.dataset.baseRotation = randomRotate;
  cd.style.zIndex = index + 1;
});

// Drag and Drop Logic
let activeCD = null;
let offsetX = 0, offsetY = 0;
let highestZ = 10;

cds.forEach(cd => {
  cd.addEventListener('pointerdown', (e) => {
    activeCD = cd;
    highestZ++;
    activeCD.style.zIndex = highestZ;
    activeCD.classList.add('dragging');
    
    // Play grab sound (clone it so rapid clicks don't cut off)
    sfxGrab.cloneNode(true).play().catch(() => {});

    const rect = activeCD.getBoundingClientRect();
    offsetX = e.clientX - rect.left;
    offsetY = e.clientY - rect.top;
    
    // Disable CSS transform positioning temporarily for pure X/Y movement
    activeCD.style.transform = `rotate(${activeCD.dataset.baseRotation}deg)`;
  });
});

document.addEventListener('pointermove', (e) => {
  if (!activeCD) return;

  // Move the CD
  const x = e.clientX - offsetX;
  const y = e.clientY - offsetY;
  activeCD.style.left = `${x}px`;
  activeCD.style.top = `${y}px`;

  // Collision detection with the DVD drive
  const cdRect = activeCD.getBoundingClientRect();
  const driveRect = drive.getBoundingClientRect();

  // Check if CD center is near the drive
  const cdCenterX = cdRect.left + cdRect.width / 2;
  const cdCenterY = cdRect.top + cdRect.height / 2;

  if (
    cdCenterX > driveRect.left &&
    cdCenterX < driveRect.right &&
    cdCenterY > driveRect.top &&
    cdCenterY < driveRect.bottom
  ) {
    drive.classList.add('active-drop');
  } else {
    drive.classList.remove('active-drop');
  }
});

document.addEventListener('pointerup', () => {
  if (!activeCD) return;
  
  const driveIsActive = drive.classList.contains('active-drop');
  const targetLink = activeCD.getAttribute('data-link');

  if (driveIsActive) {
    // IT'S A MATCH! Insert the disc.
    sfxInsert.play().catch(() => {});
    activeCD.classList.add('inserting');
    
    // Center it on the drive slot and animate in
    const driveRect = drive.getBoundingClientRect();
    activeCD.style.left = `${driveRect.left + (driveRect.width/2) - 90}px`;
    activeCD.style.top = `${driveRect.top - 20}px`;

    // Wait for animation, then redirect
    setTimeout(() => {
      window.location.href = targetLink;
    }, 800); // Matches the CSS transition duration
    
  } else {
    // Drop back on table
    sfxDrop.cloneNode(true).play().catch(() => {});
    activeCD.style.transform = `rotate(${activeCD.dataset.baseRotation}deg)`;
  }

  activeCD.classList.remove('dragging');
  drive.classList.remove('active-drop');
  activeCD = null;
});