// Programmatic control for the frosted glass opacity
// You can call this function anywhere in your code to dynamically change the glass layer opacity.

function setGlassOpacity(value) {
  // Clamps value between 0.0 and 1.0
  const clampedValue = Math.min(Math.max(value, 0), 1);
  document.documentElement.style.setProperty('--glass-opacity', clampedValue);
}

// Example usage via code:
// setGlassOpacity(0.6); // Sets frosted glass opacity to 60%

// Add click event listeners to buttons
document.querySelectorAll('.grid-btn').forEach((btn, index) => {
  btn.addEventListener('click', () => {
    console.log(`Button ${index + 1} clicked!`);
  });
});